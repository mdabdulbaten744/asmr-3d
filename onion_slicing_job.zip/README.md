# Job: Red onion being sliced

Fully procedural (no downloads, no image textures). Blender 4.2, Cycles CPU.

- `main.py` entry point (scene, animation, auto-exposure, render)
- `common.py` node/mesh helpers
- `materials.py` onion skin, onion cut face (concentric layers), wood, stone, steel...
- `geometry.py` onion slices (surface of revolution), chef knife, skin shards
- `job.json` fps, output_name, grain, vignette, crf

Story: knife enters, cuts 8 slices (~0.7 s each), slices tip over into a row, camera drifts to the pile.
Length is about 9 s at 24 fps (~220 frames).

Quality (chosen when you run the workflow): draft 854x480, standard 1280x720, high 1920x1080.
Exposure is calibrated automatically by a few tiny probe renders before the real render.
