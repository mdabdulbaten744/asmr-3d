# -*- coding: utf-8 -*-
"""Onion (surface-of-revolution pieces) and chef knife geometry."""
import bpy
import bmesh
import math
import random
from common import make_mesh_object, orient, loft

# ---- onion dimensions (1 Blender unit = 10 cm) ----
RMAX = 0.45
L_AX = 1.05
T_TIP = 0.88
T_ROOT = 0.06
Y_TIP = -0.10
SEG = 96


def radius(t, th):
    tw = t ** 0.78
    e = max(0.0, 1.0 - (2.0 * tw - 1.0) ** 2)
    base = RMAX * math.sqrt(e) + 0.11 * (1.0 - t) ** 5 + 0.03 * t ** 4
    dev = (1.0 + 0.020 * math.sin(3 * th + 0.6) + 0.012 * math.sin(7 * th - 1.1 + 5.0 * t)
           + 0.007 * math.sin(11 * th + 12.0 * t))
    return base * dev


def y_of_t(t):
    return Y_TIP + (T_TIP - t) * L_AX


def rest_height():
    best = 0.0
    for i in range(121):
        t = T_ROOT + (T_TIP - T_ROOT) * i / 120.0
        for s in range(180):
            th = 2.0 * math.pi * s / 180.0
            best = max(best, -radius(t, th) * math.sin(th))
    return best


def lowest_z_after_lean(t_lo, t_hi, phi):
    y_mid = y_of_t(0.5 * (t_lo + t_hi))
    best = 1e9
    for j in range(5):
        t = t_hi - (t_hi - t_lo) * j / 4.0
        yl = y_of_t(t) - y_mid
        for s in range(120):
            th = 2.0 * math.pi * s / 120.0
            z = yl * math.sin(phi) + radius(t, th) * math.sin(th) * math.cos(phi)
            best = min(best, z)
    return best


def build_piece(name, t_lo, t_hi, nax, mat_skin, mat_flesh, loc):
    y_mid = y_of_t(0.5 * (t_lo + t_hi))
    verts, faces, mats, smooth, rpos = [], [], [], [], []
    rings = []
    for j in range(nax + 1):
        t = t_hi - (t_hi - t_lo) * j / nax
        yl = y_of_t(t) - y_mid
        ids = []
        for s in range(SEG):
            th = 2.0 * math.pi * s / SEG
            r = radius(t, th)
            ids.append(len(verts))
            verts.append((r * math.cos(th), yl, r * math.sin(th)))
            rpos.append((t, math.cos(th), math.sin(th)))
        rings.append(ids)
    for j in range(nax):
        for s in range(SEG):
            f = [rings[j][s], rings[j][(s + 1) % SEG], rings[j + 1][(s + 1) % SEG], rings[j + 1][s]]
            cx = sum(verts[i][0] for i in f) / 4.0
            cz = sum(verts[i][2] for i in f) / 4.0
            faces.append(orient(f, verts, (cx, 0.0, cz)))
            mats.append(0)
            smooth.append(True)
    for t_cap, ny in ((t_hi, -1.0), (t_lo, 1.0)):
        yl = y_of_t(t_cap) - y_mid
        c0 = len(verts)
        verts.append((0.0, yl, 0.0))
        rpos.append((t_cap, 0.0, 0.0))
        rim = []
        for s in range(SEG):
            th = 2.0 * math.pi * s / SEG
            r = radius(t_cap, th)
            rim.append(len(verts))
            verts.append((r * math.cos(th), yl, r * math.sin(th)))
            rpos.append((t_cap, math.cos(th), math.sin(th)))
        for s in range(SEG):
            faces.append(orient([c0, rim[s], rim[(s + 1) % SEG]], verts, (0.0, ny, 0.0)))
            mats.append(1)
            smooth.append(False)
    return make_mesh_object(name, verts, faces, [mat_skin, mat_flesh], mats, smooth, rpos, loc)


# ------------------------------------------------------------- knife
def _interp(pts, x):
    if x <= pts[0][0]:
        return pts[0][1]
    for i in range(len(pts) - 1):
        x0, z0 = pts[i]
        x1, z1 = pts[i + 1]
        if x <= x1:
            u = (x - x0) / (x1 - x0) if x1 > x0 else 0.0
            return z0 + (z1 - z0) * u
    return pts[-1][1]


def build_blade(mat):
    edge_pts = [(-1.10, 0.18), (-1.00, 0.09), (-0.85, 0.035), (-0.65, 0.008), (-0.40, 0.0),
                (0.40, 0.0), (0.70, 0.015), (0.90, 0.045)]
    spine_pts = [(-1.10, 0.20), (-0.90, 0.31), (-0.60, 0.385), (-0.20, 0.425),
                 (0.20, 0.445), (0.60, 0.455), (0.90, 0.46)]
    N = 48
    bm = bmesh.new()
    cols = []
    for i in range(N + 1):
        x = -1.10 + 2.0 * i / N
        ze, zs = _interp(edge_pts, x), _interp(spine_pts, x)
        h = zs - ze
        z1, z2 = ze + min(0.05, h * 0.30), ze + min(0.14, h * 0.60)
        v0 = bm.verts.new((x, 0.0, ze))
        spec = ((0.0045, z1), (0.011, z2), (0.0125, zs))
        vp = [bm.verts.new((x, yy, zz)) for yy, zz in spec]
        vm = [bm.verts.new((x, -yy, zz)) for yy, zz in spec]
        cols.append((v0, vp, vm))
    for i in range(N):
        a, b = cols[i], cols[i + 1]
        for side in (1, 2):
            ra, rb = [a[0]] + a[side], [b[0]] + b[side]
            for r in range(3):
                bm.faces.new((ra[r], rb[r], rb[r + 1], ra[r + 1]))
        bm.faces.new((a[1][2], b[1][2], b[2][2], a[2][2]))
    for col in (cols[0], cols[N]):
        v0, vp, vm = col
        bm.faces.new([vm[2], vm[1], vm[0], v0, vp[0], vp[1], vp[2]])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = bpy.data.meshes.new("Blade_mesh")
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = True
    me.materials.append(mat)
    ob = bpy.data.objects.new("Blade", me)
    bpy.context.scene.collection.objects.link(ob)
    return ob


def build_knife(mat_steel, mat_handle):
    """Returns the root empty. Its origin = centre of the cutting edge."""
    root = bpy.data.objects.new("KnifeRoot", None)
    bpy.context.scene.collection.objects.link(root)
    parts = [build_blade(mat_steel)]
    handle = [(0.90, 0.0, 0.29, 0.060, 0.140, 2.6), (0.98, 0.0, 0.29, 0.085, 0.170, 2.6),
              (1.30, 0.0, 0.29, 0.100, 0.165, 2.6), (1.75, 0.0, 0.29, 0.103, 0.155, 2.6),
              (2.10, 0.0, 0.29, 0.095, 0.140, 2.6), (2.28, 0.0, 0.29, 0.070, 0.110, 2.4)]
    parts.append(loft("Handle", handle, 40, mat_handle))
    try:
        for i, x in enumerate((1.12, 1.58, 2.02)):
            r = loft("Rivet%d" % i, [(-0.12, 0.0, 0.0, 0.028, 0.028, 2.0),
                                      (0.12, 0.0, 0.0, 0.028, 0.028, 2.0)], 16, mat_steel)
            r.location = (x, 0.0, 0.29)
            r.rotation_euler = (0.0, 0.0, math.pi / 2.0)
            parts.append(r)
    except Exception as exc:
        print("WARN rivets skipped:", exc)
    for p in parts:
        p.parent = root
    return root


def build_shard(name, sx, sy, loc, yaw, mat, seed):
    rnd = random.Random(seed)
    nu = nv = 10
    verts, faces = [], []
    for i in range(nu + 1):
        u = -1.0 + 2.0 * i / nu
        for j in range(nv + 1):
            v = -1.0 + 2.0 * j / nv
            w = 1.0 - 0.55 * u * u
            z = 0.012 + 0.09 * u * u + 0.05 * abs(v) ** 1.5 + 0.01 * math.sin(5.0 * u + seed)
            verts.append((u * sx, v * sy * w, z))
    for i in range(nu):
        for j in range(nv):
            a = i * (nv + 1) + j
            f = [a, a + (nv + 1), a + (nv + 2), a + 1]
            faces.append(orient(f, verts, (0.0, 0.0, 1.0)))
    n = len(faces)
    ob = make_mesh_object(name, verts, faces, [mat], [0] * n, [True] * n, None, loc)
    ob.rotation_euler = (0.0, 0.0, yaw + rnd.uniform(-0.1, 0.1))
    m = ob.modifiers.new("Solid", "SOLIDIFY")
    m.thickness = 0.006
    m.offset = 0.0
    return ob
