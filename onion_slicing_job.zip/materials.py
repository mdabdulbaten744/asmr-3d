# -*- coding: utf-8 -*-
"""All procedural materials. No image textures, nothing downloaded."""
import bpy
from common import (S, new_mat, set_in, col4, MATH, MIX, noise_node, ramp_node, bump_node)


def _rpos(nt):
    at = nt.nodes.new("ShaderNodeAttribute")
    at.attribute_type = "GEOMETRY"
    at.attribute_name = "rpos"
    return at.outputs["Vector"]


def onion_flesh():
    """Cut face. 'rpos' = (t, ny, nz); radius of (ny,nz) drives concentric layers."""
    mat, nt, bsdf = new_mat("Onion_Flesh")
    vec = _rpos(nt)
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    nt.links.new(vec, sep.inputs["Vector"])
    Yc, Zc = sep.outputs["Y"], sep.outputs["Z"]
    A = lambda op, a=None, b=None, c=False: MATH(nt, op, a, b, c)

    rho = A("SQRT", A("ADD", A("MULTIPLY", Yc, Yc), A("MULTIPLY", Zc, Zc)))
    nfac = noise_node(nt, vec, 5.0, 3.0, 0.55).outputs["Fac"]
    rhow = A("MAXIMUM", A("ADD", rho, A("MULTIPLY", A("SUBTRACT", nfac, 0.5), 0.07)), 0.0)
    f = A("MULTIPLY", rhow, 12.0)
    fl = A("FLOOR", f)
    frac = A("FRACT", f)
    edge = A("MULTIPLY", A("ABSOLUTE", A("SUBTRACT", frac, 0.5)), 2.0)
    line = A("DIVIDE", A("SUBTRACT", edge, 0.70), 0.28, True)
    wn = nt.nodes.new("ShaderNodeTexWhiteNoise")
    wn.noise_dimensions = "1D"
    nt.links.new(fl, wn.inputs["W"])
    rnd = wn.outputs["Value"]

    pale, green = S(0.93, 0.89, 0.90), S(0.85, 0.90, 0.72)
    mag_mid, mag_deep, rind_c = S(0.80, 0.40, 0.55), S(0.45, 0.08, 0.24), S(0.30, 0.07, 0.17)

    s1 = A("DIVIDE", A("SUBTRACT", rho, 0.2), 0.7, True)
    tint = A("MULTIPLY", s1, A("ADD", A("MULTIPLY", rnd, 0.85), 0.15))
    c = MIX(nt, A("MULTIPLY", tint, 0.8), pale, mag_mid)
    core = A("MULTIPLY", A("SUBTRACT", 1.0, A("DIVIDE", rho, 0.4, True)), 0.85)
    c = MIX(nt, core, c, green)
    line_amt = A("MULTIPLY", line, A("ADD", A("MULTIPLY", rho, 0.8), 0.2))
    c = MIX(nt, line_amt, c, mag_deep)
    rind = A("DIVIDE", A("SUBTRACT", rho, 0.955), 0.02, True)
    c = MIX(nt, rind, c, rind_c)
    nt.links.new(c, bsdf.inputs["Base Color"])

    nt.links.new(A("ADD", A("MULTIPLY", nfac, 0.22), 0.14), bsdf.inputs["Roughness"])
    h = A("SUBTRACT", 1.0, A("MULTIPLY", line, 0.8))
    nt.links.new(bump_node(nt, h, 0.6, 0.012), bsdf.inputs["Normal"])
    set_in(bsdf, ["Subsurface Weight", "Subsurface"], 0.30)
    set_in(bsdf, "Subsurface Radius", (0.10, 0.06, 0.07))
    set_in(bsdf, ["Specular IOR Level", "Specular"], 0.5)
    set_in(bsdf, ["Coat Weight", "Clearcoat"], 0.35)
    set_in(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.05)
    return mat


def onion_skin():
    mat, nt, bsdf = new_mat("Onion_Skin")
    vec = _rpos(nt)
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (1.8, 9.0, 9.0)
    nt.links.new(vec, mp.inputs["Vector"])
    nz = noise_node(nt, mp.outputs["Vector"], 1.0, 7.0, 0.6, 0.3)
    nf = nz.outputs["Fac"]
    ramp = ramp_node(nt, nf, [
        (0.00, S(0.22, 0.035, 0.10)), (0.40, S(0.45, 0.08, 0.20)),
        (0.65, S(0.62, 0.17, 0.30)), (0.85, S(0.75, 0.32, 0.40)),
        (1.00, S(0.85, 0.50, 0.52))])
    nt.links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(MATH(nt, "ADD", MATH(nt, "MULTIPLY", nf, 0.30), 0.26), bsdf.inputs["Roughness"])
    nt.links.new(bump_node(nt, nf, 0.6, 0.012), bsdf.inputs["Normal"])
    set_in(bsdf, ["Specular IOR Level", "Specular"], 0.6)
    set_in(bsdf, ["Coat Weight", "Clearcoat"], 0.25)
    set_in(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.12)
    return mat


def wood():
    mat, nt, bsdf = new_mat("Board_Wood")
    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (0.30, 1.0, 1.0)
    nt.links.new(tc.outputs["Object"], mp.inputs["Vector"])
    wv = nt.nodes.new("ShaderNodeTexWave")
    wv.wave_type = "BANDS"
    wv.bands_direction = "Y"
    wv.wave_profile = "SIN"
    nt.links.new(mp.outputs["Vector"], wv.inputs["Vector"])
    for k, v in (("Scale", 9.0), ("Distortion", 7.0), ("Detail", 4.0),
                 ("Detail Scale", 1.3), ("Detail Roughness", 0.6)):
        wv.inputs[k].default_value = v
    fine = noise_node(nt, mp.outputs["Vector"], 60.0, 4.0, 0.6).outputs["Fac"]
    ramp = ramp_node(nt, wv.outputs["Fac"], [
        (0.0, S(0.46, 0.28, 0.14)), (0.55, S(0.62, 0.41, 0.22)), (1.0, S(0.74, 0.54, 0.33))])
    col = MIX(nt, MATH(nt, "MULTIPLY", fine, 0.35), ramp.outputs["Color"], S(0.30, 0.17, 0.08))
    nt.links.new(col, bsdf.inputs["Base Color"])
    nt.links.new(MATH(nt, "ADD", MATH(nt, "MULTIPLY", fine, 0.2), 0.38), bsdf.inputs["Roughness"])
    h = MATH(nt, "ADD", MATH(nt, "MULTIPLY", wv.outputs["Fac"], 0.5), MATH(nt, "MULTIPLY", fine, 0.5))
    nt.links.new(bump_node(nt, h, 0.25, 0.004), bsdf.inputs["Normal"])
    return mat


def stone():
    mat, nt, bsdf = new_mat("Counter_Stone")
    tc = nt.nodes.new("ShaderNodeTexCoord")
    n1 = noise_node(nt, tc.outputs["Object"], 50.0, 10.0, 0.6).outputs["Fac"]
    ramp = ramp_node(nt, n1, [(0.0, S(0.045, 0.045, 0.05)), (1.0, S(0.14, 0.14, 0.15))])
    nt.links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(MATH(nt, "ADD", MATH(nt, "MULTIPLY", n1, 0.2), 0.18), bsdf.inputs["Roughness"])
    nt.links.new(bump_node(nt, n1, 0.1, 0.003), bsdf.inputs["Normal"])
    return mat


def wall():
    mat, nt, bsdf = new_mat("Wall_Teal")
    set_in(bsdf, "Base Color", col4(S(0.07, 0.12, 0.13)))
    set_in(bsdf, "Roughness", 0.55)
    return mat


def steel():
    mat, nt, bsdf = new_mat("Knife_Steel")
    set_in(bsdf, "Base Color", col4(S(0.80, 0.82, 0.85)))
    set_in(bsdf, "Metallic", 1.0)
    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (2.0, 2.0, 150.0)
    nt.links.new(tc.outputs["Object"], mp.inputs["Vector"])
    br = noise_node(nt, mp.outputs["Vector"], 1.0, 3.0, 0.5).outputs["Fac"]
    nt.links.new(MATH(nt, "ADD", MATH(nt, "MULTIPLY", br, 0.12), 0.16), bsdf.inputs["Roughness"])
    nt.links.new(bump_node(nt, br, 0.15, 0.002), bsdf.inputs["Normal"])
    return mat


def plastic():
    mat, nt, bsdf = new_mat("Knife_Handle")
    set_in(bsdf, "Base Color", col4(S(0.04, 0.04, 0.045)))
    set_in(bsdf, "Roughness", 0.32)
    set_in(bsdf, ["Coat Weight", "Clearcoat"], 0.2)
    return mat


def paper():
    mat, nt, bsdf = new_mat("Onion_Paper")
    set_in(bsdf, "Base Color", col4(S(0.48, 0.10, 0.20)))
    set_in(bsdf, "Roughness", 0.55)
    return mat


def emission(color, strength):
    mat = bpy.data.materials.new("Bokeh")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Color"].default_value = col4(color)
    em.inputs["Strength"].default_value = strength
    nt.links.new(em.outputs["Emission"], out.inputs["Surface"])
    return mat
