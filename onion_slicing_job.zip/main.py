# -*- coding: utf-8 -*-
"""
ONION SLICING - photoreal procedural Blender scene (Cycles CPU, Blender 4.2).
Run by GitHub Actions:
  blender -b --python main.py -- --job-dir <dir> --out <dir> --quality draft|standard|high
Writes PNG frames to <out>/frames/frame_####.png (the workflow encodes the MP4).
1 Blender unit = 10 cm.
"""
import os
import sys
import math
import random
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy
from mathutils import Vector
from common import get_args, load_cfg, make_box, make_mesh_object, orient
import materials as MT
import geometry as G

T0_WALL = time.time()
random.seed(11)
ARGS = get_args()
CFG = load_cfg(ARGS.job_dir)
FPS = int(CFG.get("fps", 24))
OUT = ARGS.out
FRAMES_DIR = os.path.join(OUT, "frames")
os.makedirs(FRAMES_DIR, exist_ok=True)

QUALITY = {
    "draft": {"res": (854, 480), "samples": 20, "probe": 2},
    "standard": {"res": (1280, 720), "samples": 64, "probe": 3},
    "high": {"res": (1920, 1080), "samples": 112, "probe": 3},
}
Q = QUALITY[ARGS.quality]

N_SLICES = 8
SLICE_T = 0.085
DT = SLICE_T / G.L_AX
T_INTRO, T_CYCLE, T_OUTRO = 1.5, 0.70, 2.0
TOTAL = T_INTRO + N_SLICES * T_CYCLE + T_OUTRO
ZT = 1.30  # knife edge height when lifted


def fr(sec):
    return 1.0 + sec * FPS


END = int(math.ceil(fr(TOTAL)))


def y_cut(k):
    return G.Y_TIP + SLICE_T * (k + 1)


# ------------------------------------------------------------ scene setup
def clear_scene():
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob, do_unlink=True)
    for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.lights,
                 bpy.data.cameras, bpy.data.worlds):
        for d in list(coll):
            try:
                coll.remove(d)
            except Exception:
                pass


clear_scene()
scene = bpy.context.scene


def link(ob):
    scene.collection.objects.link(ob)
    return ob


def empty(name, loc):
    e = bpy.data.objects.new(name, None)
    e.location = loc
    return link(e)


def sph(target, dist, az_deg, el_deg):
    az, el = math.radians(az_deg), math.radians(el_deg)
    return Vector((target[0] + dist * math.cos(el) * math.sin(az),
                   target[1] - dist * math.cos(el) * math.cos(az),
                   target[2] + dist * math.sin(el)))


def add_area(name, loc, target, energy, sx, sy, color):
    ld = bpy.data.lights.new(name, "AREA")
    ld.energy = energy
    ld.shape = "RECTANGLE"
    ld.size = sx
    ld.size_y = sy
    ld.color = color
    ob = link(bpy.data.objects.new(name, ld))
    ob.location = loc
    c = ob.constraints.new("TRACK_TO")
    c.target = target
    c.track_axis = "TRACK_NEGATIVE_Z"
    c.up_axis = "UP_Y"
    return ob


def build_scene():
    mat_skin, mat_flesh = MT.onion_skin(), MT.onion_flesh()
    # counter, board, wall
    make_box("Counter", 60, 60, 0.5, (0, 0, -0.45), MT.stone())
    make_box("Board", 5.0, 3.6, 0.2, (0, 0, -0.1), MT.wood(), bevel=0.03, seg=4)
    make_box("Wall", 60, 0.4, 30, (0, 5.2, 14.8), MT.wall())

    # onion: 8 slices + remainder
    z0 = G.rest_height()
    slices = []
    rnd = random.Random(5)
    for k in range(N_SLICES):
        t_hi = G.T_TIP - k * DT
        t_lo = t_hi - DT
        ymid = G.y_of_t(0.5 * (t_hi + t_lo))
        ob = G.build_piece("Slice%d" % k, t_lo, t_hi, 4, mat_skin, mat_flesh, (0.0, ymid, z0))
        lean = math.radians(7.0 + rnd.uniform(-0.5, 0.5))
        yaw = math.radians(rnd.uniform(-1.8, 1.8))
        zf = -G.lowest_z_after_lean(t_lo, t_hi, lean) + 0.004
        loc1 = (-0.50 + rnd.uniform(-0.04, 0.04), -1.00 + 0.158 * k, zf)
        slices.append({"ob": ob, "loc0": (0.0, ymid, z0), "loc1": loc1, "lean": lean, "yaw": yaw})
    t_hi = G.T_TIP - N_SLICES * DT
    t_lo = G.T_ROOT
    ymid = G.y_of_t(0.5 * (t_hi + t_lo))
    G.build_piece("OnionRemainder", t_lo, t_hi, 8, mat_skin, mat_flesh, (0.0, ymid, z0))

    # knife
    knife = G.build_knife(MT.steel(), MT.plastic())

    # skin shards on the board
    try:
        pm = MT.paper()
        for i, (x, y, yaw, s) in enumerate(((1.3, -1.0, 0.6, 0.30), (0.4, -1.5, 2.1, 0.22),
                                            (1.9, -0.4, 1.1, 0.26), (-1.8, 0.9, 2.8, 0.28))):
            G.build_shard("Shard%d" % i, s, s * 0.7, (x, y, 0.0), yaw, pm, i + 3)
    except Exception as exc:
        print("WARN shards skipped:", exc)

    # bokeh lights on wall
    try:
        rr = random.Random(9)
        palette = [(1.0, 0.72, 0.42), (1.0, 0.55, 0.30), (0.75, 0.85, 1.0)]
        emats = [MT.emission(c, 7.0) for c in palette]
        for i in range(16):
            rad = rr.uniform(0.10, 0.22)
            v = [(0.0, 0.0, 0.0)] + [(rad * math.cos(2 * math.pi * s / 24), 0.0,
                                      rad * math.sin(2 * math.pi * s / 24)) for s in range(24)]
            f = [orient([0, 1 + s, 1 + (s + 1) % 24], v, (0.0, -1.0, 0.0)) for s in range(24)]
            make_mesh_object("Bokeh%d" % i, v, f, [emats[i % 3]], [0] * 24, [False] * 24, None,
                             (rr.uniform(-5.5, 5.5), 4.95, rr.uniform(0.7, 4.3)))
    except Exception as exc:
        print("WARN bokeh skipped:", exc)

    # world
    world = bpy.data.worlds.new("World")
    scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes["Background"]
    bg.inputs[0].default_value = (0.02, 0.022, 0.028, 1.0)
    bg.inputs[1].default_value = 0.6

    # lights
    aim = empty("Aim", (0.0, 0.1, 0.35))
    add_area("Key", (-3.4, -2.6, 4.4), aim, 1400, 3.2, 3.2, (1.0, 0.95, 0.88))
    add_area("RimL", (-2.8, 3.8, 3.2), aim, 900, 2.2, 2.2, (1.0, 0.85, 0.70))
    add_area("RimR", (2.8, 3.6, 2.4), aim, 450, 2.0, 2.0, (0.85, 0.92, 1.0))
    add_area("Fill", (4.2, -3.0, 2.0), aim, 200, 4.0, 4.0, (0.80, 0.88, 1.0))
    return slices, knife


# ------------------------------------------------------------ animation
def key(ob, t, loc=None, rot=None):
    if loc is not None:
        ob.location = loc
        ob.keyframe_insert("location", frame=fr(t))
    if rot is not None:
        ob.rotation_euler = rot
        ob.keyframe_insert("rotation_euler", frame=fr(t))


def animate(slices, knife):
    rad = math.radians

    def kk(t, x, y, z, deg):
        key(knife, t, (x, y, z), (0.0, rad(deg), 0.0))

    kk(0.0, 2.8, y_cut(0), 2.4, -9)
    kk(T_INTRO - 0.25, 0.30, y_cut(0), ZT, -7)
    for k in range(N_SLICES):
        s, y = T_INTRO + k * T_CYCLE, y_cut(k)
        kk(s, 0.30, y, ZT, -7)
        kk(s + 0.30, -0.30, y, 0.0, 0)      # blade reaches the board = cut done
        kk(s + 0.37, -0.30, y, 0.0, 0)
        kk(s + 0.53, 0.15, y, ZT, -6)       # lift, then step to next cut
    s_last = T_INTRO + (N_SLICES - 1) * T_CYCLE
    kk(s_last + 1.20, 2.0, y_cut(N_SLICES - 1), 3.6, -15)
    kk(TOTAL, 2.6, y_cut(N_SLICES - 1), 4.2, -15)

    for k, d in enumerate(slices):
        ob = d["ob"]
        t_cut = T_INTRO + k * T_CYCLE + 0.30
        key(ob, 0.0, d["loc0"], (0.0, 0.0, 0.0))
        key(ob, t_cut, d["loc0"], (0.0, 0.0, 0.0))
        key(ob, t_cut + 0.30, d["loc1"], (d["lean"], 0.0, d["yaw"]))

    # camera + focus
    focus = empty("Focus", (0.0, 0.20, 0.45))
    cd = bpy.data.cameras.new("Cam")
    cd.lens, cd.sensor_width, cd.clip_start, cd.clip_end = 45.0, 36.0, 0.05, 200.0
    cd.dof.use_dof = True
    cd.dof.focus_object = focus
    cd.dof.aperture_fstop = 0.45
    cd.dof.aperture_blades = 7
    cam = link(bpy.data.objects.new("Camera", cd))
    c = cam.constraints.new("TRACK_TO")
    c.target = focus
    c.track_axis = "TRACK_NEGATIVE_Z"
    c.up_axis = "UP_Y"
    scene.camera = cam

    T0, T1, T2 = (0.0, 0.20, 0.45), (-0.05, 0.35, 0.45), (-0.45, -0.40, 0.30)
    t_cut_end = T_INTRO + N_SLICES * T_CYCLE
    key(focus, 0.0, T0)
    key(focus, t_cut_end - 0.3, T1)
    key(focus, TOTAL, T2)
    key(cam, 0.0, tuple(G_sph(T0, 6.4, 34, 28)))
    key(cam, t_cut_end, tuple(G_sph(T1, 5.9, 31, 27)))
    key(cam, TOTAL, tuple(G_sph(T2, 4.8, 26, 24)))


def G_sph(t, d, az, el):
    return sph(t, d, az, el)


# ------------------------------------------------------------ render config
def configure_render():
    r = scene.render
    r.engine = "CYCLES"
    r.resolution_x, r.resolution_y = Q["res"]
    r.resolution_percentage = 100
    r.fps, r.fps_base = FPS, 1.0
    scene.frame_start, scene.frame_end = 1, END
    r.image_settings.file_format = "PNG"
    r.image_settings.color_mode = "RGB"
    r.image_settings.color_depth = "8"
    r.use_motion_blur = True
    r.motion_blur_shutter = 0.45
    r.use_persistent_data = True
    cy = scene.cycles
    cy.device = "CPU"
    cy.samples = Q["samples"]
    cy.use_adaptive_sampling = True
    cy.adaptive_threshold = 0.03
    cy.use_denoising = True
    cy.denoiser = "OPENIMAGEDENOISE"
    cy.max_bounces, cy.diffuse_bounces, cy.glossy_bounces = 8, 3, 4
    cy.transmission_bounces, cy.volume_bounces = 4, 0
    cy.sample_clamp_indirect = 8.0
    try:
        cy.caustics_reflective = False
        cy.caustics_refractive = False
    except Exception:
        pass
    vs = scene.view_settings
    for tr in ("AgX", "Filmic"):
        try:
            vs.view_transform = tr
            break
        except TypeError:
            continue
    for lk in ("Medium High Contrast", "AgX - Medium High Contrast"):
        try:
            vs.look = lk
            break
        except TypeError:
            continue


def auto_exposure():
    """Quick low-res probe renders to set exposure (no guessing light units)."""
    r, cy, vs = scene.render, scene.cycles, scene.view_settings
    saved = (r.resolution_x, r.resolution_y, r.resolution_percentage, cy.samples,
             cy.use_denoising, cy.use_adaptive_sampling, r.filepath, r.use_motion_blur,
             scene.frame_current)
    probe = os.path.join(OUT, "_probe.png")
    try:
        r.resolution_x, r.resolution_y, r.resolution_percentage = 192, 108, 100
        cy.samples, cy.use_denoising, cy.use_adaptive_sampling = 8, False, False
        r.use_motion_blur = False
        scene.frame_set(int(round(fr(T_INTRO + 3 * T_CYCLE + 0.34))))
        target = 0.40 ** 2.2
        for i in range(Q["probe"]):
            r.filepath = probe
            bpy.ops.render.render(write_still=True)
            img = bpy.data.images.load(probe)
            try:
                img.colorspace_settings.name = "Non-Color"
            except Exception:
                pass
            w, h = img.size
            px = list(img.pixels)
            ch = img.channels if img.channels else 4
            tot, n = 0.0, 0
            for y in range(int(h * 0.2), int(h * 0.8)):
                for x in range(int(w * 0.22), int(w * 0.78)):
                    j = (y * w + x) * ch
                    lum = 0.2126 * px[j] + 0.7152 * px[j + 1] + 0.0722 * px[j + 2]
                    tot += max(lum, 0.0) ** 2.2
                    n += 1
            bpy.data.images.remove(img)
            cur = max(tot / max(n, 1), 1e-4)
            vs.exposure = max(-4.0, min(4.0, vs.exposure + 0.85 * math.log2(target / cur)))
            print("auto-exposure pass %d -> %.2f EV" % (i + 1, vs.exposure))
    except Exception as exc:
        print("WARN auto-exposure skipped:", exc)
    finally:
        (r.resolution_x, r.resolution_y, r.resolution_percentage, cy.samples,
         cy.use_denoising, cy.use_adaptive_sampling, r.filepath, r.use_motion_blur,
         cur_frame) = saved
        scene.frame_set(cur_frame)
        try:
            os.remove(probe)
        except Exception:
            pass


def main():
    print("Blender", bpy.app.version_string, "| quality", ARGS.quality, "| frames", END)
    slices, knife = build_scene()
    animate(slices, knife)
    configure_render()
    auto_exposure()
    scene.render.filepath = os.path.join(FRAMES_DIR, "frame_")
    print("Rendering %d frames at %dx%d, %d samples" % (END, Q["res"][0], Q["res"][1], Q["samples"]))
    bpy.ops.render.render(animation=True)
    print("Done in %.1f min" % ((time.time() - T0_WALL) / 60.0))


main()
