# -*- coding: utf-8 -*-
"""Shared helpers (node builders, mesh builders, CLI). Blender 4.2 API."""
import bpy
import math
import os
import sys
import json
import argparse
from mathutils import Vector


def get_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1:] if "--" in argv else []
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser()
    ap.add_argument("--job-dir", default=here)
    ap.add_argument("--out", default=os.path.join(os.getcwd(), "output"))
    ap.add_argument("--quality", default="standard", choices=["draft", "standard", "high"])
    return ap.parse_args(argv)


def load_cfg(job_dir):
    cfg = {"fps": 24}
    p = os.path.join(job_dir, "job.json")
    if os.path.isfile(p):
        try:
            with open(p, "r", encoding="utf-8") as fh:
                cfg.update(json.load(fh))
        except Exception as exc:
            print("WARN: job.json unreadable:", exc)
    return cfg


def S(r, g, b):
    """sRGB (0-1) -> scene-linear tuple."""
    def f(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return (f(r), f(g), f(b))


# ---------------------------------------------------------------- nodes
def new_mat(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat, nt, bsdf


def set_in(node, names, value):
    if isinstance(names, str):
        names = [names]
    for nm in names:
        if nm in node.inputs:
            try:
                node.inputs[nm].default_value = value
                return True
            except Exception:
                pass
    return False


def col4(c):
    return (c[0], c[1], c[2], 1.0)


def MATH(nt, op, a=None, b=None, clamp=False):
    n = nt.nodes.new("ShaderNodeMath")
    n.operation = op
    n.use_clamp = clamp
    for i, v in ((0, a), (1, b)):
        if v is None:
            continue
        if isinstance(v, bpy.types.NodeSocket):
            nt.links.new(v, n.inputs[i])
        else:
            n.inputs[i].default_value = float(v)
    return n.outputs[0]


def MIX(nt, fac, c1, c2):
    n = nt.nodes.new("ShaderNodeMixRGB")
    n.blend_type = "MIX"
    if isinstance(fac, bpy.types.NodeSocket):
        nt.links.new(fac, n.inputs[0])
    else:
        n.inputs[0].default_value = float(fac)
    for idx, c in ((1, c1), (2, c2)):
        if isinstance(c, bpy.types.NodeSocket):
            nt.links.new(c, n.inputs[idx])
        else:
            n.inputs[idx].default_value = col4(c)
    return n.outputs[0]


def noise_node(nt, vec, scale=5.0, detail=2.0, rough=0.5, distortion=0.0):
    n = nt.nodes.new("ShaderNodeTexNoise")
    if vec is not None:
        nt.links.new(vec, n.inputs["Vector"])
    n.inputs["Scale"].default_value = scale
    n.inputs["Detail"].default_value = detail
    n.inputs["Roughness"].default_value = rough
    if "Distortion" in n.inputs:
        n.inputs["Distortion"].default_value = distortion
    return n


def ramp_node(nt, fac, stops):
    """stops: ascending list of (position, linear_rgb)."""
    n = nt.nodes.new("ShaderNodeValToRGB")
    ramp = n.color_ramp
    ramp.elements[0].position = stops[0][0]
    ramp.elements[1].position = stops[-1][0]
    for pos, _c in stops[1:-1]:
        ramp.elements.new(pos)
    for i, (_p, c) in enumerate(stops):
        ramp.elements[i].color = col4(c)
    if fac is not None:
        nt.links.new(fac, n.inputs["Fac"])
    return n


def bump_node(nt, height, strength, distance):
    b = nt.nodes.new("ShaderNodeBump")
    b.inputs["Strength"].default_value = strength
    b.inputs["Distance"].default_value = distance
    nt.links.new(height, b.inputs["Height"])
    return b.outputs["Normal"]


# ---------------------------------------------------------------- meshes
def orient(face, verts, want):
    p0, p1, p2 = (Vector(verts[face[i]]) for i in range(3))
    n = (p1 - p0).cross(p2 - p0)
    if n.dot(Vector(want)) < 0.0:
        return list(reversed(face))
    return list(face)


def make_mesh_object(name, verts, faces, materials, mat_idx=None, smooth=None,
                     rpos=None, loc=(0.0, 0.0, 0.0)):
    me = bpy.data.meshes.new(name + "_mesh")
    me.from_pydata(verts, [], faces)
    me.update()
    for m in materials:
        me.materials.append(m)
    if mat_idx is not None:
        me.polygons.foreach_set("material_index", mat_idx)
    if smooth is not None:
        try:
            me.polygons.foreach_set("use_smooth", smooth)
        except Exception:
            for p, s in zip(me.polygons, smooth):
                p.use_smooth = s
    if rpos is not None:
        at = me.attributes.new(name="rpos", type="FLOAT_VECTOR", domain="POINT")
        at.data.foreach_set("vector", [c for v in rpos for c in v])
    me.update()
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    ob.location = loc
    return ob


def make_box(name, sx, sy, sz, loc, mat, bevel=0.0, seg=3):
    hx, hy, hz = sx / 2.0, sy / 2.0, sz / 2.0
    v = [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
         (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)]
    f = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    ob = make_mesh_object(name, v, f, [mat], [0] * 6, [False] * 6, None, loc)
    if bevel > 0.0:
        m = ob.modifiers.new("Bevel", "BEVEL")
        m.width = bevel
        m.segments = seg
        m.limit_method = "ANGLE"
    return ob


def loft(name, sections, seg, mat):
    """Superellipse loft along +X. sections: (x, cy, cz, ry, rz, exponent)."""
    verts, faces, rings = [], [], []
    for (x, cy, cz, ry, rz, ne) in sections:
        ids = []
        for s in range(seg):
            ph = 2.0 * math.pi * s / seg
            c, sn = math.cos(ph), math.sin(ph)
            y = cy + ry * math.copysign(abs(c) ** (2.0 / ne), c)
            z = cz + rz * math.copysign(abs(sn) ** (2.0 / ne), sn)
            ids.append(len(verts))
            verts.append((x, y, z))
        rings.append(ids)
    for i in range(len(sections) - 1):
        cy0, cz0 = sections[i][1], sections[i][2]
        for s in range(seg):
            f = [rings[i][s], rings[i][(s + 1) % seg], rings[i + 1][(s + 1) % seg], rings[i + 1][s]]
            wy = sum(verts[j][1] for j in f) / 4.0 - cy0
            wz = sum(verts[j][2] for j in f) / 4.0 - cz0
            faces.append(orient(f, verts, (0.0, wy, wz)))
    for idx, sign in ((0, -1.0), (len(sections) - 1, 1.0)):
        x, cy, cz = sections[idx][0], sections[idx][1], sections[idx][2]
        c0 = len(verts)
        verts.append((x, cy, cz))
        for s in range(seg):
            f = [c0, rings[idx][s], rings[idx][(s + 1) % seg]]
            faces.append(orient(f, verts, (sign, 0.0, 0.0)))
    n = len(faces)
    return make_mesh_object(name, verts, faces, [mat], [0] * n, [True] * n)
